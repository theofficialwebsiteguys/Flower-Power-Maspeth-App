export const environment = {
  production: true,
  apiUrl: 'https://dispensary-api-ac9613fa4c11.herokuapp.com/api',
  venueId: 'df759ba5e7360809',
  locationId: '364', // Flower Power Maspeth (SettingsService.MASPETH_LOCATION_ID in maspeth-shop, re-verified 2026-09-04)
  flower_power_api_key: '564ee591-42df-46d9-91c0-ff3507e316ec',
  aeropay_api_key: 'd1f40288-66fe-4786-8552-0417764e67a5',
  aeropay_api_secret: 'b506dd13-2d0f-4644-acfe-da065e1af934',
  aeropay_url: "https://api.aeropay.com",
  aeropay_merchant_id: 3234,
  db_api_key: 'a2f350973ce3dc4837109ef201ee98f2d3574d389295b681f7df0d42f1fc5ed6'
};
