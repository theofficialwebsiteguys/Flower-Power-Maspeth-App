// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiUrl: 'http://localhost:3333/api',
  venueId: '836944c298d40676',
  locationId: '364', // Flower Power Maspeth (SettingsService.MASPETH_LOCATION_ID in maspeth-shop, re-verified 2026-09-04)
  flower_power_api_key: '564ee591-42df-46d9-91c0-ff3507e316ec',
  aeropay_api_key: 'd1f40288-66fe-4786-8552-0417764e67a5',
  aeropay_api_secret: 'b506dd13-2d0f-4644-acfe-da065e1af934',
  aeropay_url: "https://staging-api.aeropay.com",
  aeropay_merchant_id: 0,
  db_api_key: 'a2f350973ce3dc4837109ef201ee98f2d3574d389295b681f7df0d42f1fc5ed6'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
